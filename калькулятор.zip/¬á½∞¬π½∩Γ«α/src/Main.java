import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Scanner;


public class Main {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        RomanConverter converter = new RomanConverter();
        Calculator calculator = new Calculator();
        String expression;
        System.out.println("\nКалькулятор умеет выполнять операции сложения, вычитания, умножения и деления с двумя числами:\n" +
                            "- принимает на вход только целые числа от 1 до 10(или от I до X) включительно;\n" +
                            "- умеет работать с арабскими и римскими числами одновременно('III + 3' = ошибка);");
            try {
                while(true) {
                    System.out.println("\nВведите выражение:");
                    expression = scan.nextLine();
                    expression = expression.replaceAll("\\s","");
                    Pattern pattern = Pattern.compile("((I{1,3}|IV|V|VI|VII|VII|IX|X)[\\+\\-\\*\\/](I{1,3}|IV|V|VI|VII|VII|IX|X))");
                    Matcher matcher = pattern.matcher(expression);

                    if(matcher.matches()) {
                        expression = converter.convert(expression);
                        int roman = calculator.calculate(expression);
                        String result = converter.arabicToRoman(roman);
                        System.out.println("Результат: " + result);

                    } else {
                        pattern = Pattern.compile("(([1-9]|10)[\\+\\-\\*\\/][1-9]|10)");
                        matcher =  pattern.matcher(expression);
                        int result2 = calculator.calculate(expression);
                        if(matcher.matches()) {
                            System.out.println("Результат: " + result2);
                        }
                        else throw new IOException("Введенные данные не соответствуют условиям.");
                    }
                }
            } catch (IOException e) {
            e.printStackTrace();
        }
    }
}