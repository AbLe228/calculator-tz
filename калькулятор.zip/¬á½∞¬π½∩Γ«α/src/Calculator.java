import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Calculator {

    public int calculate(String expression) {
        Pattern pattern = Pattern.compile("[\\+\\-\\*/]");
        Matcher matcher = pattern.matcher(expression);
        String operation = "";
        if(matcher.find()) {
            operation = matcher.group(0);
            int firstNum = Integer.parseInt(expression.substring(0, matcher.end(0)-1));
            int secondNum = Integer.parseInt(expression.substring(matcher.end(0)));
            switch(operation) {
                case "+":
                    return firstNum + secondNum;
                case "-":
                    return firstNum - secondNum;
                case "*":
                    return firstNum *secondNum;
                case "/":
                    return firstNum / secondNum;
            }
        }
        return 0;
    }
}