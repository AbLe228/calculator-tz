import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RomanConverter {

    public String arabicToRoman(int romanNum) throws IOException {

        if(romanNum <= 0) throw new IOException("В римской системе счисления нет 0 и отрицательных чисел.");

        String[] romanArray = {"C", "XC", "L", "X", "IX", "V", "I"};
        int[] arabicArray = {100, 90, 50, 10, 9, 5, 1};
        String romanResult = "";

        for (int i = 0; i < arabicArray.length; i++) {
            int numberInPlace = romanNum / arabicArray[i];
            if (numberInPlace == 0) continue;
            romanResult += numberInPlace == 4 && i > 0? romanArray[i] + romanArray[i - 1]:
                    new String(new char[numberInPlace]).replace("\0",romanArray[i]);
            romanNum = romanNum % arabicArray[i];
        }
        return romanResult;
    }

    public int romanToArabic(String roman) {
        switch(roman) {
            case "I": return  1;
            case "II": return 2;
            case "III": return 3;
            case "IV": return 4;
            case "V": return 5;
            case "VI": return 6;
            case "VII": return 7;
            case "VIII": return 8;
            case "IX": return 9;
            case "X": return 10;
        }
        return 0;
    }

    public String convert(String expression) {
        Pattern pattern = Pattern.compile("[\\+\\-\\*/]");
        Matcher matcher = pattern.matcher(expression);
        String operation = "";
        if(matcher.find()) {
            operation = matcher.group(0);
            String firstNum = romanToArabic(expression.substring(0, matcher.end(0)-1)) + "";
            String secondNum = romanToArabic(expression.substring(matcher.end(0))) + "";
            return firstNum + operation + secondNum;
        }
        else return null;
    }
}